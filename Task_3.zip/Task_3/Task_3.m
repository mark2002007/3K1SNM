pkg load symbolic
clc
clear
#Task_3_1(-1,1,10)
#Task_3_2();
#
#TODO : TASK 3.2.2
#
